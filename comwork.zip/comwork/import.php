<?php
	include("db.php");
	$sql = "SELECT district.name as disname, province.id as provid FROM province JOIN district ON district.province = province.name";
	$query = mysqli_query($conn, $sql) or die(mysqli_error($conn));
	var_dump($query);
	while ($data = mysqli_fetch_assoc($query)) {
		$disname = $data['disname'];
		$provid = $data['provid'];
		echo "$disname = $provid<br />";
		$query = mysqli_query($conn, "UPDATE district SET prov = '$provid' WHERE name = '$disname'") or die("weeeoe");	
	}	
?>