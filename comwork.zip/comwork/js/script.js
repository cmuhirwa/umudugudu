$("#percForm").on('submit', function(e){
	selDate = $("#selDate option:selected").val();
	selGender = $("#selGender option:selected").val();
	selPro = $("#selProf option:selected").val();

	if(selDate && selGender && selPro){
		$.post('api/perc.php', {act:'getperc', gender:selGender, date:selDate, profession:selPro}, function(data, status){
			try{
				var ret = JSON.parse(data);
				data = ret.data;
				log(typeof(data))
				if(typeof(data) == 'string'){
					num = data;
					total = ncitizen-num;
				}else if(typeof(data) == "object"){
					log(data);
					num = data.count;
					total = data.total-num;
				}
				percGraph.data.datasets[0].data = [num, total];
				percGraph.options.animation.animateScale = true;
				percGraph.update(2000, function(){alert()});
			}catch(err){
				log(err);
			}
		});
	}else if(selDate && selGender){
		$.post('api/perc.php', {act:'getperc', gender:selGender, date:selDate}, function(data, status){
			try{
				var ret = JSON.parse(data);
				num = ret.data;
				percGraph.data.datasets[0].data = [num, ncitizen-num];
				percGraph.options.animation.animateScale = true;
				percGraph.update(2000, function(){alert()});
			}catch(err){
				log(err);
			}
		});
	}else{
		$.post('api/perc.php', {act:'getperc', date:selDate}, function(data, status){
			try{
				var ret = JSON.parse(data);
				num = ret.data;
				percGraph.data.datasets[0].data = [num, ncitizen-num];
				percGraph.options.animation.animateScale = true;
				percGraph.update(2000);
			}catch(err){
				log(err);
			}
		});
	}
	e.preventDefault();
});
function summarizeGraph(data, labels){
	//labeling graph data
	loadDOM = $(".graphsummary");
	//Resetting summary data
	if(data && labels)
		loadDOM.empty();
	for(n=0; n<labels.length; n++){
		label = labels[n];
		tl = label.replace(" ", "-");
		loadDOM.append("<li id='"+tl+"SumCont'><span></span>"+label+"</li>");

		var temp = $("#"+tl+"SumCont");
		temp.addClass('summaryLabelColor');
	}
	temp.find("span").css("padding:2px")

	//Loading data
	for(n1=0; n1<data.length; n1++){

		dataElem = data[n1].data;
		var dataCont = $(".summaryLabelColor");

		for(n=0; n<dataElem.length; n++){
			$(dataCont[n]).append("<span> "+dataElem[n]+" </span>");
		}
	}

}
// $('#locGraph').on('click', function(evt){
//   var activePoint = locgraph.getElementAtEvent(event);

//   // make sure click was on an actual point
//   if (activePoint.length > 0) {
//     var clickedDatasetIndex = activePoint[0]._datasetIndex;
//     var clickedElementindex = activePoint[0]._index;
//     var label = locgraph.data.labels[clickedElementindex];
//     var value = locgraph.data.datasets[clickedDatasetIndex].data[clickedElementindex];     
//     alert("Clicked: " + label + " - " + value);
//   }
// });
function topOption(optionHTML, select){
	//Function to put an option on top in select
	elems = $(select+" option");
	added = $(optionHTML).insertBefore(elems[0]);
	$(select).html(added);
	$(select).append(elems)
}
function drawGraph(target, category, elem, options = {}){
	if(options.date)
		date =  options.date;
	else date = '';
	if(options.province)
		province =  options.province;
	else province = '';
	locgraph.destroy()
	if(category == 'locGraph'){
		$.post('api/gdata.php', {act:'load', category:category, date:date, target:target, 'province':province}, function(data){
			ret = JSON.parse(data);
			if(ret.status == 1){
			var testGraph = locgraph = new Chart(ctx, {
			type: 'bar',
			pointRadius: 5,
			data: {
				labels: ret.labels,
				datasets: [{					
					label: '# of attendance in '+target,
            		data: ret.data,
            		fill: false,
            		lineTension: 0,
            		backgroundColor: 'rgba(2, 132, 239, .39)',
            		pointHighlightStroke : "#18a689",
            		borderColor: 'rgba(2, 132, 239, .89)',
            		borderWidth: 1
				},
				{
					bezierCurve: false,
					label: '# of citizens in '+target,
            		data: ret.Ndata,
            		fill: false,
            		lineTension: 0,
            		backgroundColor: 'rgba(0, 0, 0, .1)',
            		pointHighlightStroke : "rgba(99, 132, 0, .8)",
            		borderColor: 'rgba(99, 132, 0, .4)',
            		borderWidth: 1
				}]
			},
			options: {
				bezierCurve: false,
				scales: {
					yAxes:[{
						ticks: {
							beginAtZero: true
						}
					}],
					xAxes:[{
						stacked: true,
					}]
				},
				categoryPercentage: .2,
			}
		})
			}
		});
	}else if($category == ""){

	}
}
$("#locGraph").on('click', function(){
	clicked = getClicked(locgraph);

	if(clicked){
		drawGraph('district', 'locGraph', $("#locGraph"), {province: clicked.label});
	}
});
$("#dateChoice").on('change', function(){
	choseDate = $(this).find('option:selected').val();
	choseLevel = $("#locCatSel").find('option:selected').val();

	if(choseDate)
		drawGraph(choseLevel, 'locGraph', $("#locGraph"), {date:choseDate == 'all'?"":choseDate});
})
$("#timevar").on('click', function(){
	evData = getClicked(timevar);
	if(evData){
		drawGraph('Province', 'locGraph', $("#locGraph"), {date:evData.label});
	}
	

})

function getClicked(graphObj){
	var activePoint = graphObj.getElementAtEvent(event);

	// make sure click was on an actual point
	if (activePoint.length > 0) {
	    var clickedDatasetIndex = activePoint[0]._datasetIndex;
	    var clickedElementindex = activePoint[0]._index;
	    var label = graphObj.data.labels[clickedElementindex];
	    var value = graphObj.data.datasets[clickedDatasetIndex].data[clickedElementindex];
	    return {label, value};
	}
}


function initGraph(vars){

}
function log(data){
	console.log(data)
}


	