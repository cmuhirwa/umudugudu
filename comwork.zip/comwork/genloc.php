<?php
	include("db.php");
	$get_province = mysqli_query($con,"SELECT * FROM provinces");
?>
<!DOCTYPE html>
<head>

	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <link href="css/bootstrap.min.css" rel="stylesheet">

	<title>Location Generator</title>
    
    <script type="text/javascript">	  
		//Get districts list
		function showResult(){
			var provincecode=document.getElementById('provincecode').value;
			var params = "&provincecode="+provincecode+"";
			http=new XMLHttpRequest();
			http.open("POST","getdistrict.php",true);
			http.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
			http.send(params);
			http.onreadystatechange = function() 
			{
			//Call a function when the province changes.
				
			document.getElementById("districtcode").innerHTML=http.responseText;
					
			if(document.getElementById('districtcode').value!=="No District Available")
				//document.post_form.name.disabled=false;
				;
			
			}		
		}
	    
		
	    //Get sectors list
		function showResult2(){
			var districtcode=document.getElementById('districtcode').value;
			var params = "&districtcode="+districtcode+"";
			http=new XMLHttpRequest();
			http.open("POST","getsector.php",true);
			http.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
			http.send(params);
			http.onreadystatechange = function() 
			{//Call a function when the district changes.
				
			document.getElementById("sectorcode").innerHTML=http.responseText;
					
			if(document.getElementById('sectorcode').value!=="No Sector Available")
				//document.post_form.name.disabled=false;
				;
			
			}		
		}
	
		//Get cell list
		function showResult3(){
			var sectorcode=document.getElementById('sectorcode').value;
			var params = "&sectorcode="+sectorcode+"";
			http=new XMLHttpRequest();
			http.open("POST","getcell.php",true);
			http.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
			http.send(params);
			http.onreadystatechange = function() 
			{//Call a function when the sector changes.
				
			document.getElementById("codecell").innerHTML=http.responseText;
					
			if(document.getElementById('codecell').value!=="No Cell Available")
				//document.post_form.name.disabled=false;
			;
			
			}		
		}
	
		//Get Villages list
		function showResult4(){
			var codecell=document.getElementById('codecell').value;
			var params = "&codecell="+codecell+"";

			http=new XMLHttpRequest();
			http.open("POST","getvillage.php",true);
			http.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
			http.send(params);
			http.onreadystatechange = function() 
			{//Call a function when the cell changes.
				
			document.getElementById("CodeVillage").innerHTML=http.responseText;
					
			if(document.getElementById('CodeVillage').value!=="No village Available")
				//document.post_form.name.disabled=false;
				;
			
			}		
		}
	</script>


</head>
<body >
	<div class="container">
		<h3> Cascading select from: Province - Village</h3>
	
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" class="form-horizontal" name="form" id="form" role="form" >
			<div class="form-group">
				<label for="provincecode">Province:</label>
				<select name="provincecode" class="form-control entrytext"  id="provincecode" onchange="showResult();">
					<option value="">----Select province----</option>
					<?php while($show_province = mysqli_fetch_array($get_province)) { ?>
							<option value="<?php echo $show_province['provincecode'] ?>"><?php echo $show_province['provincename'] ?></option>
					<?php } ?>
				</select>
				<p id="provError" class="text-danger"></p>
			</div>
			<div class="form-group">
				<label for="districtcode">District:</label>
				<select name="districtcode" id="districtcode" class="form-control entrytext" onchange="showResult2();">
			 	<option ></option>
			 	</select>
			</div>
			<div class="form-group">
				<label for="sectorcode">Sector:</label>
				<select name="sectorcode" id="sectorcode" class="entrytext form-control" onchange="showResult3();">
					<option> </option>
				</select>
			</div>
			<div class="form-group">
				<label for="codecell">Cell:</label>
				<select name="codecell" id="codecell" class="form-control entrytext" onchange="showResult4();">
					<option> </option>
				</select>
			</div>
			<div class="form-group">
				<label for="CodeVillage">Village:</label>
				<select name="CodeVillage" id="CodeVillage" class="form-control entrytext">
					<option> </option>
				</select>
			</div>
			<button class="btn btn-primary">GENERATE</button>

			<!-- Generated location container -->
			<div class="generated" id="genCont"></div>
		</form/>
	</div>
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript">
				//Form Elements
				var elems = {'province':"#provincecode", 'district':"#districtcode", 'sector':'#sectorcode', 'cell':'#codecell', 'village':'#CodeVillage'}				

			$('#form').on('submit', function(e){
				$("#provError").text(""); //Reseting error message which could have been set
				
				//Init container
				var dataCont = {};

				//Looping through all form elemsnts - location attributes
				for(use in elems){
					//All elements are sorted in order
					usecode = elems[use];

					//getting data about this element
					var elemData = $(usecode).find("option:selected").val();

					//Checking if element is not selected and then exiting the loop
					if(elemData == ""){

						//Checking if this empty element is province
						if(use == 'province'){							
							//set warning as province is required
							$("#provError").text("Please enter at least province");
						}

						//Brekaing the loop
						break;
					}
					dataCont[use] = elemData;					
				}
				log(dataCont);
				if(use == 'village'){
					$(".generated").text("UmuduguduID: "+dataCont['village']);
				}

				//Calling location insertion API
				// $.post('api/insertlocation.php', dataCont, function(data, status){
				// 	log(data)
				// 	//Trying to read returned JSON
				// 	try{
				// 		retData = JSON.parse(data);
				// 		if(retData.status == 1){
				// 			//Location Inserted successfully
				// 			$(".generated").text("id: "+retData.id);

				// 		}
				// 	}catch(err){
				// 		log(err);
				// 	}
				// });
				e.preventDefault();
			});

			function log(data){
				console.log(data);
			}
		</script>
								
								
</body>
</html>
