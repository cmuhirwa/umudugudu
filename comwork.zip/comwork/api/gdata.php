<?php
	include_once "../db.php";

	include_once "../class.attendance.php";
	$Attendance = new attendance();

	//Combining post and get for testing and debuggin
	$req = array_merge($_POST, $_GET);
	if(!empty($req['act']) && $req['act'] == "load"){

		if(!empty($req['category']) && !empty($req['target'])){
			$category = $req['category'];
			$target = $req['target'];
			if(!strcasecmp($category, 'locGraph')){
				if(!strcasecmp($target, "District") ){
					//Number of attendances in districts
					$date = $req['date']??'';

					//Requested district in province
					$prov = $req['province']??'';

					$dists = $Attendance->listDistrict(array('date'=>$date, 'province'=>$prov));
					$data = array_column($dists, "sum");
					$labels = array_column($dists, "name");

					//Creating a referential array to sync with Numbers of dists
					$dists = array_combine($labels, $data);

					//Number of citizens in districts
					$Ndists = $Attendance->listNDistrict();
					$Ndata = array_column($Ndists, "sum");
					$Nlabels = array_column($Ndists, "name");

					$Ndists = array_combine($Nlabels, $Ndata);

					//Syncing arrays order
					$Ndists = syncArr($dists, $Ndists);			

					//Correct format of data referenced to actual Data array
					$Ndata = array_values($Ndists);
					$Nlabels = array_keys($Ndists);

					echo json_encode(array('status'=>1, 'data'=>$data, 'labels'=>$labels, 'Ndata'=>$Ndata, 'Nlabels'=>$Nlabels));
				}else if( !strcasecmp($target, "province") ){
					//Number of attendances in province
					$date = $req['date']??'';
					$provs = $Attendance->listProvince(array('date'=>$date));
					
					$data = array_column($provs, "sum");
					//var_dump($provs);
					$labels = array_column($provs, "provincename");

					$provs = array_combine($labels, $data);

					//Number of citizens in province
					$Nprovs = $Attendance->listNProvince();
					$Ndata = array_column($Nprovs, "sum");
					$Nlabels = array_column($Nprovs, "name");

					$Nprovs = array_combine($Nlabels, $Ndata);

					//Syncing arrays order
					$Nprovs = syncArr($provs, $Nprovs);					

					//Correct format of data referenced to actual Data array
					$Ndata = array_values($Nprovs);
					$Nlabels = array_keys($Nprovs);

					echo json_encode(array('status'=>1, 'data'=>$data, 'labels'=>$labels, 'Ndata'=>$Ndata, 'Nlabels'=>$Nlabels));
				}
			}
		}else{
			echo json_encode(array('status'=>0, 'data'=>"specify target and category"));
		}

	}
	function syncArr($arr1, $arr2){
		//Two multidimensional arrays to be sorted
		$temp = array();
		foreach ($arr1 as $key1 => $value1) {
			$temp[$key1] = $arr2[$key1];
		}
		return $temp;
	}
?>