
<?php
# PHP Responder Script
$msg      = $_GET["msgdata"];
$sender   = $_GET["sender"];
$receiver = $_GET["receiver"];
//$operator = $_GET["operator"];
$receivetime = $_GET['recvtime'];
// $msgtype = $_GET['msgtype'];
// $gsmsms = $_GET['gsmsms'];

#
# Create response SMS messages
#


//Uncomment this line to send a response message

echo "{GSMSMS}{}{}{+250726396284}{The PHP plugin has received a message.}\n";

// $subscribers = Array();
// if (file_exists($fn)) { $subscribers = file($fn); }
// $command = trim(strtolower($msg));
// if ($command=="signup") {
//   if (!in_array($sender,$subscribers)) {
//     $subscribers[]=$sender;
//     echo "{GSMSMS}{}{}{"."$sender"."}{Thank you for subscribing to the list}\n";
//     $fp = fopen($fn,"w");
//     fputs($fp,join("\n",$subscribers));
//     fclose($fp);
//   } else {
//     echo "{GSMSMS}{}{}{"."$sender"."}{You have already signed up}\n";
//   }
// }

// if (!(strpos($command,'warning')===false)) {
//   foreach($subscribers as $destnumber) {
//     $destnumber = trim($destnumber);
//     if ($destnumber<>$sender) {
//        echo "{GSMSMS}{}{}{"."$destnumber"."}{".trim($msg)."}\n";
//     }
//   }
// }

	$file = fopen('sms.txt', 'a+');
	fwrite($file, "Message: $msg<br />Sender:$sender\nRecipient:$receivetime\nReceiver:$receiver\n\nWe got Them from here\n\n\n===============\n\n\n");
	fwrite($file, var_dump($_GET));

?>

