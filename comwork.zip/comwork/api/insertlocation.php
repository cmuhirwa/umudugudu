<?php
	include_once "../db.php";

  //Combining post and get for testing and debuggin
  $req = array_merge($_POST, $_GET);
  

  if(!is_array($req))
	echo "'error':'Provide data'";
  
  //decodeing json

  //Taking only recognised location items
  $locItems = array('province', 'district', 'sector', 'cell', 'village');

  $properData = array_values(array_intersect($locItems, array_keys($req)));

  //Formulating a quuery
  $sql = '';
  for($n = 0; $n<count($properData); $n++){
	$item = $properData[$n];

	$itemvalue = (int)$req[$item];
	$sql .= "'$itemvalue', ";
  }

  //Removing trailing AND
  $sql = rtrim($sql, " , ");

  //forming sql values
  $sqlValues = "`".implode("`, `", $properData)."`";
  $sqlValues = "`id`, ".$sqlValues;

  //FInal Query
  $sql = "INSERT INTO location($sqlValues) VALUES ('', $sql)";

  $query = mysqli_query($conn, $sql) OR die(json_encode(array('error'=>mysqli_error($conn))));

  $insert_id =  mysqli_insert_id($conn);
  echo json_encode(array("id"=>$insert_id, 'status'=>1));

?>