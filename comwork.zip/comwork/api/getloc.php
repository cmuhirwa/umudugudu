<?php
	include("../db.php");

	include("../location.class.php");
	$Location = new location();

	//Handling location routes

	//Combining both requests for testing
	$reqData = array_merge($_POST, $_GET);

	if(!empty($reqData['target'])){

		$target = $reqData['target']; //Desired output like sectors or cells

		//Serving the requests
		if($target == "district"){
			$prov = $reqData['data']??"";

			//Loading districts
			if(!empty($prov)){
				$districts = $Location->getDistricts($prov);
				echo json_encode($districts);
			}

		}
	}


	// $get_sector = mysqli_query($conn, "SELECT * FROM  sectors WHERE districtcode ='".$_POST['districtcode']."'");

	// echo "<select name=\"sectorcode\" id=\"sectorcode\">";
	// if(mysqli_fetch_array($get_sector)==0){
	// 	echo "<option value=\"No Sector Available\">No Sector Available</option>";
	// }else{
	
	//         echo "<option value=\"\">------Select sector------</option>";
	// 	while($row=mysqli_fetch_array($get_sector)){
	// 		echo "<option value=\"".$row['sectorcode']."\">".$row['namesector']."</option>";
	// 	}
	// }
	// echo "</select><br>";
	?>
	
