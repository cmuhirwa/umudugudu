<?php
	include_once "../db.php";

	include_once "../class.attendance.php";
	$Attendance = new attendance();

	//Combining post and get for testing and debuggin
	$req = array_merge($_POST, $_GET);
	if(!empty($req['act'])){

		//Getting some promise data

		$date = $req['date']??"";
		$date = $date=='all'?'':$date;
		$gender = $req['gender']??"";
		$gender = $gender == 'all'?null:$gender;
		$profession = $req['profession']??"";
		$profession = $profession == 'all'?null:$profession;
		
		unset($req['act']);
		$data = $Attendance->numAttended($req);
		echo json_encode(array('status'=>1, 'data'=>$data));
	}
?>