<?php
	include_once("db.php");
	class profession{
		public function id($name)
		{
			global $conn;
			$name = mysqli_real_escape_string($conn, $name);

			$query = mysqli_query($conn, "SELECT id FROM profession WHERE name = \"$name\"") or die(elog(mysqli_error($conn)));
			if(mysqli_num_rows($query) >0){
				$data = mysqli_fetch_assoc($query);
				return $data['id'];
			}else return 0;		
		}
	}
	$Profession = new profession();
?>

	
