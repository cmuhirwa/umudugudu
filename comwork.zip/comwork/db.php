<?php


   $conn = $con = mysqli_connect("localhost","root","","comwork");
   //Check connection
   if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }
   function elog($data){
   	echo __LINE__." IN ".__FILE__."  ".$data;;
   }
?>
