<?php
	class location{
		public function getProvinces(){
			//Function to get provinces
			global $conn;
			
			$query  = mysqli_query($conn, "SELECT * FROM province") or die(mysqli_error($conn));
			$provinces = array(); //initialising provinces container

			while($data = mysqli_fetch_assoc($query)){
				$provinces[$data['id']] = $data['name'];
			}
			return $provinces;
		}
		public function getDistricts($provID){
			/*@param $provData is the data like name or id 
			/*@param $dataType is data type specifying $provID
			*/

			//Function to get provinces
			global $conn;
			$provID  = mysqli_real_escape_string($conn, $provID);

			$query = "SELECT * FROM district WHERE province = '$provID'";			
			$query  = mysqli_query($conn, $query) or die("error:"+mysqli_error($conn));
			

			$districts = array(); //initialising districts container
			while($data = mysqli_fetch_assoc($query)){
				$districts[$data['code']] = $data['name'];
			}
			return $districts;
		}
	}
?>