<?php
	include_once("db.php");
	include_once("class.citizen.php");
	class attendance extends citizen{
		function listProvince($data = array()){
			global $conn;

			if(!empty($data['req']) && $data['req'] == 'date'){
				//Listing provinces with dates
				$query = mysqli_query($conn, "SELECT COUNT(umugandaDate) as sum, provinces.provincename, umugandaDate FROM attendance JOIN provinces ON LEFT(umudugudu, 1)  = provinces.provincecode GROUP BY umugandaDate") or die(elog(mysqli_error($conn)));
				$provs = array();
				while ($data = mysqli_fetch_assoc($query)) {
					var_dump($data);
					$provs[] = $data;
				}
				return $provs;
			}
			else if(!empty($data['date']) && $data['date'] !='all' ){
				//Listing provinces  attenace on $date
				$date = $data['date'];
				$date = mysqli_real_escape_string($conn, $date);

				$sql = "SELECT COUNT(umugandaDate) as sum, provinces.provincename, umugandaDate FROM attendance JOIN provinces ON LEFT(umudugudu, 1)  = provinces.provincecode WHERE umugandaDate = \"$date\" GROUP BY provincename";
				//echo "$sql";

				$query = mysqli_query($conn, $sql) or die(elog(mysqli_error($conn)));
				$provs = array();
				while ($data = mysqli_fetch_assoc($query)) {
					$provs[] = $data;
				}
				return $provs;
			}else{
				//Listing provinces attending the umuganda
				$query = mysqli_query($conn, "SELECT provincename, provincecode, COUNT(DISTINCT(citizen)) as sum FROM attendance JOIN provinces ON LEFT(umudugudu, 1) = provinces.provincecode GROUP BY provincename ORDER BY sum DESC") or die(elog(mysqli_error($conn)));
			}

			$provs = array();
			while ($data = mysqli_fetch_assoc($query)) {
				$provs[] = $data;
			}
			return $provs;
		}
		function listUmuganda(){
			//Function to return imiganda and their attendance
			global $conn;
			$query  = mysqli_query($conn, "SELECT COUNT(DISTINCT(id)) AS sum, umugandaDate FROM `attendance` GROUP BY umugandaDate") or die(elog(mysqli_error($conn)));
			$ret = array();
			while($data = mysqli_fetch_assoc($query)){
				$ret[] = $data;
			}
			return $ret;
		}
		function provname2id($prov){
			global $conn;
			$query = mysqli_query($conn, "SELECT provincecode FROM provinces WHERE provincename = \"$prov\"") or die(elog(mysqli_error($conn)) );
			if(mysqli_num_rows($query)>0){
				$data = mysqli_fetch_assoc($query);
				return $data['provincecode'];
			}else return 0;
		}
		function listDistrict($data = array()){
			global $conn;

			if(!empty($data['province'])){
				//Listing district  attendance  province
				$prov = $data['province']??"";
				$prov = mysqli_real_escape_string($conn, $prov);
				$provID = !is_numeric($prov)?$this->provname2id($prov):$prov;

				$sql = "SELECT COUNT(umugandaDate) as sum, namedistrict as name, umugandaDate FROM attendance JOIN districts ON LEFT(umudugudu, 3)  = districts.districtcode WHERE provincecode = '$provID' GROUP BY namedistrict ORDER BY sum DESC";

				$query = mysqli_query($conn, $sql) or die(elog(mysqli_error($conn)));
				$dists = array();
				while ($data = mysqli_fetch_assoc($query)) {
					$dists[] = $data;
				}
				return $dists;
			}else if(!empty($data['date']) && $data['date']!='all'){
				//Listing district  attendance  on $date
				$date = $data['date']??"";
				$date = mysqli_real_escape_string($conn, $date);

				$sql = "SELECT COUNT(umugandaDate) as sum, namedistrict as name, umugandaDate FROM attendance JOIN districts ON LEFT(umudugudu, 3)  = districts.districtcode WHERE umugandaDate = '$date' GROUP BY namedistrict ORDER BY sum DESC";
				// /echo "$sql";

				$query = mysqli_query($conn, $sql) or die(elog(mysqli_error($conn)));
				$dists = array();
				while ($data = mysqli_fetch_assoc($query)) {
					$dists[] = $data;
				}
				return $dists;
			}else{
				$query = mysqli_query($conn, "SELECT COUNT(DISTINCT(citizen)) AS sum, districtcode, namedistrict as name FROM attendance JOIN districts ON LEFT(umudugudu, 3) = districts.districtcode GROUP BY name ORDER BY sum DESC") or die(elog(mysqli_error($conn)));
				$dists = array();
				while ($data = mysqli_fetch_assoc($query)) {
					$dists[] = $data;
				}
				return $dists;
			}
			
		}
		function listSector(){
			global $conn;

			$query = mysqli_query($conn, "SELECT COUNT(*) AS sum, sectorcode as code, namesector as name FROM attendance JOIN sectors ON LEFT(umudugudu, 5) = sectors.sectorcode GROUP BY name") or die(elog(mysqli_error($conn)));
			$sects = array();
			while ($data = mysqli_fetch_assoc($query)) {
				$sects[] = $data;
			}
			return $sects;
		}
		function listCell(){
			global $conn;

			$query = mysqli_query($conn, "SELECT COUNT(*) AS sum, codecell as code, nameCell as name FROM attendance JOIN cells ON LEFT(umudugudu, 7) = cells.codecell GROUP BY name") or die(elog(mysqli_error($conn)));
			$cells = array();
			while ($data = mysqli_fetch_assoc($query)) {
				$cells[] = $data;
			}
			return $cells;
		}
		function listProfession(){
			global $conn;

			$query = mysqli_query($conn, "SELECT COUNT(DISTINCT(attendance.citizen)) as sum, name FROM `attendance` JOIN citizen ON attendance.citizen = citizen.id JOIN profession ON citizen.profession = profession.id GROUP BY name ORDER BY sum DESC LIMIT 30") or die(elog(mysqli_error($conn)));
			$pros = array();
			while ($data = mysqli_fetch_assoc($query)) {
				$pros[] = $data;
			}
			return $pros;
		}
		function numMale(){
			global $conn;

			$query = mysqli_query($conn, "SELECT COUNT(*) AS count FROM attendance JOIN citizen ON attendance.citizen = citizen.id  WHERE gender =  'M' ") or die(mysqli_error($conn));
			$data = mysqli_fetch_assoc($query);
			return $data['count'];
		}
		function numFemale(){
			global $conn;

			$query = mysqli_query($conn, "SELECT COUNT(*) AS count FROM attendance JOIN citizen ON attendance.citizen = citizen.id WHERE gender =  'F' ") or die(mysqli_error($conn));
			$data = mysqli_fetch_assoc($query);
			return $data['count'];
		}
		function numAttended($data = array()){
			global $conn;

			$profession = $data['profession']??"";
			$profession = $profession == 'all'?null:$profession;
			$date = $data['date']??"";
			$date = $date=='all'?'':$date;
			$gender = $data['gender']??"";
			$gender = $gender == 'all'?null:$gender;

			if(!empty($data['profession'])){
				if(!is_numeric($profession) && $profession!=''){
					//Searchimg the id of profession
					include_once "class.profession.php";
					$prof_id = $Profession->id($profession);

					$data['profession'] = $prof_id;
					return $this->numAttended($data);
				}
			}

			$debug = array('date'=>$date, 'gender'=>$gender, 'profession'=>$profession);
			//var_dump($debug);

			if(!empty($date) && !empty($gender) && !empty($profession) ){
				//When we need attended people on $date who are $profession
				$sql = "SELECT COUNT(*) AS count FROM attendance JOIN citizen ON attendance.citizen = citizen.id WHERE umugandaDate = \"$date\" AND gender =\"$gender\" AND citizen.profession = '$profession'";
				$query = mysqli_query($conn, $sql) or die(elog(mysqli_error($conn)));
				$data = mysqli_fetch_assoc($query);

				//Number of $gender who are $profession
				$sum = $this->nGenPro($gender, $profession);

				return array('count'=>$data['count'], 'total'=>$sum);
			}else if(!empty($date) && !empty($gender)){
				//When we need attended people on $date who are $gender
				$sql = "SELECT COUNT(*) AS count FROM attendance JOIN citizen ON attendance.citizen = citizen.id WHERE umugandaDate = \"$date\" AND gender =\"$gender\"";
				$query = mysqli_query($conn, $sql) or die(elog(mysqli_error($conn)));
				$data = mysqli_fetch_assoc($query);

				//Sum of $gender
				$sum = $this->nGender($gender);

				return array('count'=>$data['count'], 'total'=>$sum);
			}else if(!empty($date) && !empty($profession)){
				//When we need attended people on $date who are $profession
				$sql = "SELECT COUNT(*) AS count FROM attendance JOIN citizen ON attendance.citizen = citizen.id WHERE umugandaDate = \"$date\" AND profession =\"$profession\"";
				$query = mysqli_query($conn, $sql) or die(elog(mysqli_error($conn)));
				$data = mysqli_fetch_assoc($query);

				//Sum of $profession
				$sum = $this->nProfession($profession);

				return array('count'=>$data['count'], 'total'=>$sum);
			}else if(!empty($gender) && !empty($profession)){
				//When we need attended people of $gender who are $profession
				$sql = "SELECT COUNT(*) AS count FROM attendance JOIN citizen ON attendance.citizen = citizen.id WHERE gender =\"$gender\" AND profession ='$profession'";
				$query = mysqli_query($conn, $sql) or die(elog(mysqli_error($conn)));
				$data = mysqli_fetch_assoc($query);

				//Number of $gender who are $profession
				$sum = $this->nGenPro($gender, $profession);

				return array('count'=>$data['count'], 'total'=>$sum);
			}else if(!empty($date)){
				//When we need attended people on $date
				$query = mysqli_query($conn, "SELECT COUNT(DISTINCT(attendance.citizen)) AS count FROM attendance WHERE umugandaDate = \"$date\"") or die(elog(mysqli_error($conn)));
				$data = mysqli_fetch_assoc($query);
				return $data['count'];
			}else if( !empty($gender) ){
				//Specific simple search  values
				$gender = $data['gender'];
				$query = "SELECT COUNT(*) as count FROM attendance JOIN citizen ON attendance.citizen = citizen.id WHERE gender = \"$gender\"";
				// echo "$query";
				$query = mysqli_query($conn, $query) or die(elog(mysqli_error($conn)));
				$data = mysqli_fetch_assoc($query);

				//Count of $gender
				$sum = $this->nGender($gender);

				return array('count'=>$data['count'], 'total'=>$sum);
			}else if( !empty($profession) ){
				//Specific simple search  values
				$sql = "SELECT  COUNT(DISTINCT(citizen)) as count FROM attendance JOIN citizen ON attendance.citizen = citizen.id WHERE profession = \"$profession\"";
				//echo $sql;
				$query = mysqli_query($conn, $sql) or die(elog(mysqli_error($conn)));
				$data = mysqli_fetch_assoc($query);

				//Sum of $profession
				$sum = $this->nProfession($profession);

				return array('count'=>$data['count'], 'total'=>$sum);

			}else{
				$query = mysqli_query($conn, "SELECT  COUNT(DISTINCT(citizen)) AS count FROM attendance") or die(mysqli_error($conn));
				$data = mysqli_fetch_assoc($query);
				return $data['count'];
			}

			
		}
		function setAttendance($citizen, $umudugudu){
			//Here we are marking the citizen's attendance
			global $conn;

			$citizen = mysqli_real_escape_string($conn, $citizen);
			$umudugudu = mysqli_real_escape_string($conn, $umudugudu);

			//Umuganda Dates

			//Determing the month we have to account the umuganda
			$umugandaDay = $this->UmugandaDay();

			//Changing today's date against standard umuganda date
			if(date('d-m') >= $umugandaDay){
				//Should be recorder as this month
				$udate = "$umugandaDay-".date('Y');
			}else{
				//Last month
				$pmonth = date('m')-1;
				$udate = $this->UmugandaDay($pmonth)."-".date('Y');
			}
			$udate = date("Y-m-d", strtotime($udate)); //Chaning date in SQL style

			$query = "INSERT INTO attendance(citizen, umudugudu, umugandaDate) VALUES(\"$citizen\", \"$umudugudu\", \"$udate\")";
			$query = mysqli_query($conn, $query) or die(mysqli_error($conn));
			return true;
		}
		function dates($max = 20){
			//Function which returns dates on which umuganda was done.
			global $conn;
			$query = mysqli_query($conn, "SELECT DISTINCT(umugandaDate) as date FROM `attendance` ORDER BY date DESC LIMIT $max") or die(elog(mysqli_error($conn)));
			$dates = array();
			while ($data = mysqli_fetch_assoc($query)) {
				$dates[] = $data['date'];
			}
			return $dates;
		}
		function UmugandaDay($month = 0){
			// Function to find the day of umuganda in a month
			$date = date("m/Y");
			$date = explode("/", $date);

			$month = $month<=12&&$month>0?$month:$date[0];

			$ndays = cal_days_in_month(CAL_GREGORIAN, $month, $date[1]);

			//Calculating the umuganda date
			$lastweek = $ndays-7;
			for($n=1; $n<=7; $n++){
				$dt = ($lastweek+$n)."-$month-$date[1]";

				$dt = strtotime($dt);
				if(date("D", $dt) == "Sat"){
					return $lastweek+$n."-$month";
				}
			}
		}
	}