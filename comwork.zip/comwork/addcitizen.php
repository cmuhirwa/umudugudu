<?php
	include("db.php");

	//Initial consts
	$umudugudu_code = 1;
	$umuganda_code = 1;

	include_once "location.class.php";
	//Location instance
	$Location = new location();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Comm work</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Login form -->
    <link rel="stylesheet" type="text/css" href="css/form-login.css">

    <link rel="stylesheet" type="text/css" href="css/style.css">
    
  </head>
  <body>
    <!-- You only need this form and the form-login.css -->

    <form class="form-login" method="post" action="#">

        <div class="form-log-in-with-email">

            <div class="form-white-background">

            <?php
            	if(!empty($_POST['name'])){
            		$name  = $_POST['name'];
            		$dis  = $_POST['dis'];
            		$sect  = $_POST['sect'];
            		$number  = $_POST['number'];


            		//Checking code
            		$rand = rand(1000, 9999);
            		$dist = rand(1, 30);

            		$lquery= "INSERT INTO location VALUES ('', '$dist', '$sect')";


            		$lquery = mysqli_query($conn, $lquery) or die("Error with location".mysqli_error($conn));

            		$locID = mysqli_insert_id($conn);



            		$query = mysqli_query($conn, "INSERT INTO customer VALUES ('', '$name', '', '$rand', '$locID')") or die(mysqli_error($conn));

            		?>
            			<div id="qrcode">
            				<h1>User accepted</h1>
            				<p>WIth code: <?php echo $rand; ?></p>
            				<script type="text/javascript">
            					var qrcode = new QRCode("qrcode");
            					qrcode.makeCode("<?php echo $rand; ?>");
            				</script>
            			</div>
            		<?php
            		die();
            	}
                ?>

                <div class="form-title-row">
                    <h1>Register User</h1>
                </div>
                

                <div class="form-row">
                    <label>
                        <span>Names</span>
                        <input type="text" name="name">
                    </label>
                </div>

                <div class="form-row">
                        <label for="provIn">Province</label>
                        <select class="form-control" id="provIn">
                        	<option>Select Province</option>                        
	                        <?php
	                        	$provinces = $Location->getProvinces();

	                        	//Looping through provinces
	                        	foreach ($provinces as $provcode => $provname) {
	                        		?>
	                        		<option value="<?php echo $provcode; ?>"><?php echo $provname; ?></option>
	                        		<?php
	                        	}
	                        ?>
                    	</select>
                </div>

                <div class="form-row">
                    <label for="disIn">District</label>
                    <select class="form-control" id="disIn">
                    	<option>Select District</option>                
                        
                	</select>
                </div>

                <div class="form-row">
                    <label>
                        <span>Sector</span>
                        <input type="text" name="sect">
                    </label>

                </div>
                 <div class="form-row">
                    <label>
                        <span>Mobile Number</span>
                        <input type="number" name="number">
                    </label>
                </div>

                <div class="form-row">
                    <button type="submit">Register</button>
                </div>

            </div>

        </div>

    </form>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

    <script type="text/javascript">
    	$("#provIn").on('change', function(){
    		//Checking the chosen province
    		var district = $(this).find("option:selected").val();
    		if(district!=''){
    			//Getting sectors
    			$.post('api/getloc.php', {'target':'district', "data":district}, function(data){
    				try{
    					districts = jQuery.parseJSON(data);

    					for(id in districts){
    						//Loading districts
    						$("#disIn").append("<option value=\""+id+"\">"+districts[id]+"</option>")
    					}



    					log(districts);
    				}catch(err){
    					log("error with return data: "+err);
    				}
    			})
    		}
    	});
    	function log(data){
    		console.log(data);
    	}
    </script>
  </body>
</html>