<?php
	$date = date("m/Y");
	$date = explode("/", $date);
	$ndays = cal_days_in_month(CAL_GREGORIAN, $date[0], $date[1]);

	//Calculating the umuganda date
	$lastweek = $ndays-7;
	for($n=1; $n<=7; $n++){
		$dt = "$date[1]/$date[0]/".($lastweek+$n);
		//echo " $dt ";
		$dt = strtotime($dt);
		if(date("D", $dt) == "Sat"){
			echo "($lastweek+$n)";
		}

	}
	
?>