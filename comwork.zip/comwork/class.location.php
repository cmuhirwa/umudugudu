<?php
	include_once("db.php");
	class attendance{
		function listProvince(){
			global $conn;
			//Listing provinces attending the umuganda
			$query = mysqli_query($conn, "SELECT provincename, provincecode, COUNT(*) as sum FROM attendance JOIN provinces ON LEFT(umudugudu, 1) = provinces.provincecode GROUP BY provincename") or die(elog(mysqli_error($conn)));
		}
		function listDistrict(){
			global $conn;

			$query = mysqli_query($conn, "SELECT COUNT(*) AS sum, districtcode, namedistrict FROM attendance JOIN districts ON LEFT(umudugudu, 3) = districts.districtcode GROUP BY namedistrict") or die(elog(mysqli_error($conn)));
			$dists = array();
			while ($data = mysqli_fetch_assoc($query)) {
				$dists[] = $data;
			}
			return $dists;
		}
	}