<?php
	include("db.php");

	include_once "class.authority.php";
	$Authority = new authority();

	include_once "class.citizen.php";
	$Citizen = new citizen();

	include_once "class.attendance.php";
	$Attendance = new attendance();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>Prototype</title>

	<!-- Bootstrap -->
	<link href="css/bootstrap.min.css" rel="stylesheet">

	<link href="css/style.css" rel="stylesheet">
  </head>
  <body>

	<div class="container display-none">
		<form method="post" role="form" action="<?php echo $_SERVER['PHP_SELF'] ?>">
			<div class="form-group">
				<label for="user-select">Select Sample user</label>
				<select class="custom-select form-control" id="user-select" name="user">
				  <?php
					$auths = $Authority->getSamplePhones();
					for($n = 0; $n<count($auths); $n++){
						$tphone = $auths[$n];
						?>
						<option value="<?php echo $tphone; ?>"><?php echo $tphone; ?></option>
						<?php
					}
				?>
				</select>
			</div>
			<div class="form-group">
				<label for="citizensIn">Enter citizens</label>
				<i class="text-warning">Separate IDs with comma</i>
				<textarea class="form-control" rows="2" id="citizensIn"  name="citizens" required="required"></textarea>
			</div>

			<button class="btn btn-primary">Submit</button>
		</form>

		<div>
			<?php
				if(!empty($_POST['user'])){
					$user = mysqli_real_escape_string($conn, $_POST['user']);

					//Checking user-authority's details
					$auth = $Authority->check($user, 'phone');
					$authLocation = $auth['umudugudu'];

					//If authority does not exist
					if(!$auth){
						echo "We do not have your phone as the administrative authority, Please contact us for your queries.";
						die();
					}


					echo "$auth[fname]<br />";

					$citizens = $_POST['citizens']??"";

					if(empty($citizens))
						die("Please enter citizens");

					$citizens = mysqli_real_escape_string($conn, $citizens);

					//Removing spaces and double commas
					$citizens = str_ireplace(" ", "", $citizens);

					for(; strpos($citizens, ',,'); ){
						$citizens = str_ireplace(",,", ",", $citizens);
					}

					$citizens = trim($citizens, ",");

					//Putting users in an array
					$citizens = explode(",", $citizens);				

					//Removing duplicate users
					$citizens = array_unique($citizens);

					echo "<br /><br />";

					//Checking citizens codes in those locations
					$matchedCitizen = array();
					foreach($citizens as $citizen){
						//Checking IDs and mobile phones
						if(strlen($citizen) <5){
							$temp = $Citizen->checkInWork($citizen, $authLocation);
							echo $citizen." : $authLocation";
							var_dump($temp);
							echo "<br /><br />";

							if($temp){
								//Comfirming attendance of this citizen
								$matchedCitizen[] = $temp;

								$Attendance->setAttendance($temp['id'], $temp['umudugudu']);
							}
						}else if (strlen($citizen) == 10 || strlen($citizen) == 12) {
							//Pattern can be a phone number
							$temp = $Citizen->check($citizen, 'phone');
							if($temp){
								//Saving the data
								$Attendance->setAttendance($temp['id'], $temp['umudugudu']);
							}
						}else{
							//Don't know how
						}
						

					}

				}
			?>
		</div>
	</div>

	<div class="container display-non">
		<div class="jumbotron">
		  <h1 class="display-3">Attendance number against population!</h1>
		  <p class="lead"></p>
		  <hr class="my-4">
		  <?php
		  	$attended = $Attendance->numAttended();
		  	$ncitizen = $Citizen->numCitizen(); //Number of citizens
		  	$percattend = $attended*100/ $ncitizen;

		  	$male = $Attendance->numMale();
		  	$female = $Attendance->numFemale();
		  	$sum = $male + $female;

		  	$male = ($male/$sum)*100;
		  	$female = ($female/$sum)*100;

		  	//Location stats
		  	$locationsPerc = $Citizen->getLocationAttendance(); //List of top 25 villages
		  ?>
		  <p>All: <?php echo number_format($percattend) ?> %</p>
		  <hr class="my-4">
		  <p>Gender: (M <?php echo number_format($male)."%"; ?>) / (F <?php  echo number_format($female)."%"; ?>)</p>
		  <hr class="my-4">
		  <p>Locations:</p>
			<i class="block">Province</i>
			  <?php 
			  	$provs = $Attendance->listProvince();
			  	$tProv = array_sum(array_column($provs, 'sum'));
			  	foreach ($provs as $provData) {
			  		echo $provData['provincename']." : ".number_format($provData['sum']*100/$tProv)."%<br />";
			  	}
			  ?>

			<p></p>
			<i class="block">District</i>
		  	<?php 
			  	$dists = $Attendance->listDistrict();
			  	$tDist = array_sum(array_column($dists, 'sum'));
			  	foreach ($dists as $disData) {
			  		echo $disData['name']." : ".number_format($disData['sum']*100/$tDist)."%<br />";
		  		}
		  	?>

			<p></p>
			<i class="block">Sector</i>
		  	<?php 
			  	$sects = $Attendance->listSector();
			  	$tSect = array_sum(array_column($sects, 'sum'));
			  	foreach ($sects as $secData) {
			  		echo $secData['name']." : ".number_format($secData['sum']*100/$tSect)."%<br />";
			  	}
		  	?>

		  	<p></p>
			<i class="block">Cell</i>
		  	<?php 
			  	$cells = $Attendance->listCell();
			  	$tCell = array_sum(array_column($cells, 'sum'));
			  	foreach ($cells as $cellData) {
			  		echo $cellData['name']." : ".number_format($cellData['sum']*100/$tCell)."%<br />";
			  	}
		  	?>

		  	<p></p>
		  	<i class="block">Village</i>
		  	<?php
			  	$totalAttendees = array_sum(array_column($locationsPerc, 'sum'));
			  	$nvillages = count($locationsPerc); //Total villages attending umuganda
			  	$totalVilAttendance = array_sum(array_column($locationsPerc, 'sum'));
			  	for($n=0; $n<$nvillages; $n++){
			  		$temp = $locationsPerc[$n];
			  		$perc = $temp['sum']*100/$totalVilAttendance;
			  		echo $temp['VillageName'].": ".number_format($perc)."%<br />";
			  	}
		  	?>
		  <hr class="my-4">
		  <?php $lpros = $pros = $Attendance->listProfession(); ?>
		  <p>Top <?php echo count($pros); ?> - Professions:</p>
		  <?php
		  	
		  	$totalProsAttend = array_sum(array_column($pros, 'sum'));
		  	foreach ($pros as $pro) {
		  		$proPerc = $pro['sum']*100/$totalProsAttend;
		  		echo $pro['name']." ".number_format($proPerc)."% <br />";
		  	}
		  ?>
		  <hr class="my-4">
		  <p class="lead">
			<a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
		  </p>
		</div>
	</div>
	<div class="container display-non">
		<?php
            // /shuffle($provs);
            $provNData = $Citizen->listNProvince();
            $countProv = count($provNData);
            $provNData = "[".implode(array_column($provNData, 'sum'), ', ')."]";            
			$provAtData = array_column($provs, 'sum');
			$provAtData = "[".implode(($provAtData), ', ')."]";
			$provAtLabels = array_column($provs, 'provincename');
			$provAtLabels = "['".implode($provAtLabels, "', '")."']";
		?>
		<div class="atgraph">
			<div class="row">
				<div class="col-sm-8">
					<div class="card">
					  <div class="card-block">
					    <h2 class="card-title">Umuganda attendance</h2>
					    <p class="card-text">Provided here are the percentages of attendance in different locations, gender, and dates.</p>
					    <form role="form" id="percForm">
					    	<div class="form-group">
					    		<div class="col-sm-3"><p>Choose the date: </p></div>
					    		<div class="col-sm-4">
					    			<?php $dates = $Attendance->dates(); ?>
						    			<select id="selDate" class="form-control" name="selDate">
						    				<option value="all">All</option>
							    		<?php
							    		for($n=0; $n<count($dates); $n++){					    			
							    			?>
							    				<option value="<?php echo $dates[$n] ?>"><?php echo $dates[$n] ?></option>
							    			<?php
							    		}
						    		?>
					    		</select>	
					    		</div>
					    		<div class="clearfix"></div>
					    	</div>
					    	<div class="form-group">
					    		<div class="col-sm-3"><p>Gender: </p></div>
					    		<div class="col-sm-4">
					    			<?php $dates = $Attendance->dates(); ?>
						    			<select id="selGender" class="form-control" name="selDate">
						    				<option value="all">All</option>
						    				<option value="F">Female</option>
						    				<option value="M">Male</option>							    		
						    		?>
					    		</select>	
					    		</div>
					    		<div class="clearfix"></div>
					    	</div>
					    	<div class="form-group">
					    		<div class="col-sm-3"><p>Profession: </p></div>
					    		<div class="col-sm-4">
					    			<?php $profs = $Citizen->listProfession(); ?>
						    			<select id="selProf" class="form-control" name="selDate">
						    				<option value="all">All</option>
						    				<?php
						    					foreach ($profs as $data) {
						    						?>
						    						<option value="<?php echo $data['id'] ; ?>"><?php echo 	$data['name']; ?></option>
						    						<?php
						    						}
						    				?>
					    		</select>	
					    		</div>
					    		<div class="clearfix"></div>
					    	</div>
					    	<button class="btn btn-primary">Load Stats</button>
					    </form>
					   <!--  <div class="dropdown">
                            <button class="dropdown-toggle btn btn-primary" data-toggle="dropdown">Choose <span class="caret"></span></button>
                            <ul class="dropdown-menu dropdown-menu-bottom" id="chooseGraph">
                                <li><a href="#">Pie</a></li>
                                <li><a href="#">Line</a></li>
                                <li><a href="#">Bar</a></li>
                                <li><a href="#">Doughnut</a></li>
                            </ul>
                        </div> -->
					  </div>
					</div>
				</div>
				<div class="col-sm-4">
					<canvas id="attendance"></canvas>
					<div class="graphsummary">
					</div>
				</div>
			</div>
			
		</div>
		<div class="timegraph">
			<div>
				<h2>Time Variation statistics</h2>
                <div class="timevar">
                    <select id="">
                        <option value="Province">Province</option>
                        <option value="District">District</option>
                    </select>
                </div>
			</div>
			<form role="form" method="POST">
			</form>
			<canvas id="timevar"></canvas>
		</div>
		<div class="locgraph">
			<div>
				<h2>Location statistics</h2>
                <div class="locCatSel">
                    <select id="locCatSel">
                        <option value="Province">Province</option>
                        <option value="District">District</option>
                    </select>
                    <select id="dateChoice">
                        <option value="all">All</option>
                        <?php
				    		for($n=0; $n<count($dates); $n++){					    			
				    			?>
				    			<option value="<?php echo $dates[$n] ?>"><?php echo $dates[$n] ?></option>
				    			<?php
				    		}
			    		?>
                    </select>
                </div>
			</div>
			<form role="form" method="POST">
			</form>
			<canvas id="locGraph"></canvas>
		</div>


		<!-- <div class="profgraph">
			<h4>Profession statistics</h4>
			<canvas id="profgraph"></canvas>
		</div> -->		
	</div>


	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

	<script src="js/chartjs/Chart.bundle.min.js"></script>
	<!-- https://github.com/emn178/Chart.PieceLabel.js -->
	<script src="js/chartjs/piecelabel.js"></script>
	<script type="text/javascript">
		var at = document.getElementById('attendance');
		var allAttended = <?php echo $attended; ?>, ncitizen = <?php echo $ncitizen; ?>;
		Chart.defaults.global.tooltipCornerRadius = 0;
		Chart.defaults.global.backgroundColor = "rgba(0,160,0,0.8)";

		var percGraph = new Chart(at, {
				type: 'pie',
				fill: true,
				data:{
					labels: ['Attended', 'Not attended'],
					datasets: [{
						label: 'Attendance',
                        fill: true,
						backgroundColor: ['#2980b9', "#e67e22"],
                        //backgroundColor: 'rgba(41, 128, 185, .6)', 
                        //fillColor : "rgba(140, 210, 196, 0.20)",
                        //borderColor:'rgba(2, 132, 239, .69)',
						data:[allAttended, ncitizen-allAttended],
					}]
				},
				options:{
					pieceLabel:{
						mode: 'percentage'
					},
					rotation: Math.PI*.5,
					cutoutPercentage: 0,
					animation:{
						animateScale: true,
						onComplete: function(){summarizeGraph(this.data.datasets, this.data.labels)}
					}
				}
		});
	</script>
	<script type="text/javascript">
		var ctx = document.getElementById("locGraph");
		var testGraph = locgraph = new Chart(ctx, {
			type: 'bar',
			pointRadius: 5,
			data: {
				labels: <?php echo $provAtLabels; ?>,
				datasets: [{
					label: '# of attendance in provinces',
            		data: <?php echo $provAtData; ?>,
            		fill: true,
                    lineTension: 0,
            		backgroundColor: 'rgba(2, 132, 239, .39)',
            		pointHighlightStroke : "#18a689",
            		borderColor: 'rgba(2, 132, 239, .89)',
            		borderWidth: 1
				},
                {
                    label: '# of citizens in provinces',
                    data: <?php echo $provNData; ?>,
                    lineTension: 0,
                    fill: false,
                    backgroundColor: 'rgba(0, 0, 000, .09)',
                    pointHighlightStroke : "#18a689",
                    borderColor: 'rgba(0, 0, 0, .3)',
                    borderWidth: 1   
                }]
			},
			options: {
				pieceLabel:{
					mode: 'percentage'
				},
				scales: {
					yAxes:[{
						stacked: false,
						ticks: {
							beginAtZero: true
						},
						gridLines: {
			                offsetGridLines: true
			            }
					}],
					xAxes:[{
						gridLines: {
                			offsetGridLines: true
            			},
						stacked: true,
					}]
				}
			}
		})
	</script>
    <?php $pros = $Attendance->listProfession(); ?>
	<script type="text/javascript">
		var profgraphElem = $("#profgraph");
		// profgraph = new Chart(profgraphElem, {
		// 	type: 'line',
		// 	fill: true,
		// 	data:{
		// 		labels: ['<?php echo implode(array_column($pros, 'name'), "', '"); ?>'],
				
		// 		datasets:[{
		// 			pointStyle: 'star',
  //                   lineTension:0,
  //                   fill:true,
		// 			backgroundColor: 'rgba(0, 43, 255, .5)',
		// 			borderColor: ['rgba(2, 132, 239, .89)'],
		// 			label: "# of attendance in professions",
		// 			data:[<?php echo implode(array_column($pros, 'sum'), ", "); ?>],
		// 		}]
		// 	},
		// 	options: {
		// 		scales: {
		// 			yAxes:[{
		// 				ticks: {
		// 					beginAtZero: true
		// 				}
		// 			}]
		// 		}
		// 	}

		// })
	</script>
    <script type="text/javascript">
    	locStack = ['province', 'district', 'sector', 'cell', 'villlage'];

        $("#locCatSel").on('change', function(e){
            selectedView = $(this).find("option:selected").val();
            locGraphElem = $("#locGraph");
            choseDate = $('#dateChoice option:selected').val();
            log(choseDate)
            drawGraph(selectedView, 'locGraph', locGraphElem, {date:choseDate});
        })
    </script>
    <script type="text/javascript">
    	
    </script>
    <?php
    	$imigandaAtt = $Attendance->listUmuganda();
    	$ProvDates = $Attendance->listUmuganda(array('req'=>'date'));
    ?>
    <script type="text/javascript">
    	var timeVarElem = $("#timevar");

    	timevar = new Chart(timeVarElem, {
    		type: 'line',
    		data:{
    			labels:['<?php echo implode(array_column($imigandaAtt, 'umugandaDate'), "', '"); ?>'],
    			datasets:[{
    				fill:true,
    				backgroundColor: 'rgba(0, 130, 25, .3)',
    				borderColor:'rgba(10, 222, 12, .4)',
    				label:"# attendance",
    				data:[<?php echo implode(array_column($imigandaAtt, 'sum'), ", "); ?>],
    			}]
    		},
    		options: {
				scales: {
					yAxes:[{
						ticks: {
							beginAtZero: true
						}
					}]
				}
			}

    	})

    </script>
	<script type="text/javascript" src="js/script.js"></script>
  </body>
</html>