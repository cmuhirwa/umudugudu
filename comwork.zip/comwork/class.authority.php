<?php
	include_once("db.php");
	class authority{
		public function getSamplePhones($count = 5){
			echo "string";
			global $conn;
			//Checking if requested number is a number
			// if(is_numeric($count)){
			// 	echo "error:arrgument should be numeric";
			// }

			$sql = "SELECT phone FROM authority LIMIT 0, $count";

			$query = mysqli_query($conn, $sql) or die(mysqli_error($conn));

			$auths = array();

			while ($data = mysqli_fetch_assoc($query)) {
				$auths[] = $data['phone'];
			}
			return $auths;
		}
		public function currentUmuganda($authority){
			global $conn;

			//checking authority
			$authData = $this->check($authority, 'id');

			if(!empty($authData)){
				//Checking the most recent
				$min_time = date("Y-m-d")." 00:00:00";
				$max_time = date("Y-m-d")." 23:59:59";
				$query = mysqli_query($conn, "SELECT * FROM umuganda WHERE Createdauthority = \"$authData[id]\" AND (date >= \"$min_time\" AND date <= \"$max_time\") LIMIT 2") or die(mysqli_error($conn));
				$data = mysqli_fetch_assoc($query);
				return $data;
			}else{
				echo "Sorry we can not finf your number";
			}
		}
		public function check($data, $type = "phone"){
			/*Function to check authority with data of type*/
			global $conn;

			$query = mysqli_query($conn, "SELECT * FROM authority WHERE `$type` = \"$data\" LIMIT 0,1") or die(mysqli_error($conn));

			if(mysqli_num_rows($query)>0){
				$data = mysqli_fetch_assoc($query);
				return $data;
			}else return false;
		}
	}
?>

	
