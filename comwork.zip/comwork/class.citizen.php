<?php
	include_once("db.php");
	class citizen{
		public function getSamplePhones($count = 5){
			global $conn;
			//Checking if requested number is a number
			// if(is_numeric($count)){
			// 	echo "error:arrgument should be numeric";
			// }

			$query = mysqli_query($conn, "SELECT phone, COUNT(phone) as num FROM authority LIMIT 0, $count") or die(mysqli_error($conn));

			$auths = array();

			while ($data = mysqli_fetch_assoc($query)) {
				$auths[] = $data['phone'];
			}
			return $auths;
		}
		function get($data, $type='phone', $need = "*"){
			// @param $data: citizen(s) identifier like phone
			// @param $type: type of $data like phone or location
			// @param @need: what we want lik *, fname, lname

			global $conn;
			$data = mysqli_real_escape_string($conn, $data);
			$type = mysqli_real_escape_string($conn, $type);
			$need = mysqli_real_escape_string($conn, $need);

			$query = mysqli_query($conn, "SELECT * FROM citizen WHERE `$type` = \"$data\"");
		}
		function listNDistrict(){
			//Number of citiizens in district
			global $conn;

			$query = mysqli_query($conn, "SELECT COUNT(DISTINCT(citizen.id)) AS sum, districtcode, namedistrict as name FROM citizen JOIN districts ON LEFT(umudugudu, 3) = districts.districtcode GROUP BY name ORDER BY sum DESC") or die(elog(mysqli_error($conn)));
			$dists = array();
			while ($data = mysqli_fetch_assoc($query)) {
				$dists[] = $data;
			}
			return $dists;
		}
		function listNProvince(){
			//Number of citiizens in province
			global $conn;

			$query = mysqli_query($conn, "SELECT COUNT(citizen.id) AS sum, provincecode, provincename as name FROM citizen JOIN provinces ON LEFT(umudugudu, 1) = provinces.provincecode GROUP BY name ORDER BY sum DESC") or die(elog(mysqli_error($conn)));
			$provs = array();
			while ($data = mysqli_fetch_assoc($query)) {
				$provs[] = $data;
			}
			return $provs;
		}

		function getLocationAttendance(){
			//Going ti check all attendance in their villages
			global $conn;
			$query = mysqli_query($conn, "SELECT COUNT(attendance.id) as sum, umudugudu, villages.VillageName FROM attendance JOIN villages ON attendance.umudugudu = villages.CodeVillage GROUP BY umudugudu ORDER BY sum DESC LIMIT 25") or die(mysqli_error($conn));


			$stats = array();
			//Extracting results
			while ( $data = mysqli_fetch_assoc($query)) {
				$stats[] = $data;
			}
			return $stats;
		}
		function checkInWork($citizenCode, $locationCode){
			//Here we are verifying citizen in a specific location with citizen code or ID
			global $conn;
			$citizenCode = mysqli_real_escape_string($conn, $citizenCode);
			$locationCode = mysqli_real_escape_string($conn, $locationCode);

			$query = mysqli_query($conn, "SELECT * FROM citizen WHERE code = \"$citizenCode\" AND umudugudu = \"$locationCode\"") or die(mysqli_error($conn));
			if(mysqli_num_rows($query)<1){
				return false;
			}else{
				$data = mysqli_fetch_assoc($query);
				return $data;
			}
		}				
		public function listProfession()
		{
			//Listing professions available
			global $conn;
			$query = mysqli_query($conn, 'SELECT * FROM profession') or die(elog(mysqli_error($conn)));
			$profs = array();
			while ($data = mysqli_fetch_assoc($query)) {
				$profs[] = $data;
			}
			return $profs;
		}
		function check($data, $type='phone', $need = "*"){
			// @param $data: citizen(s) identifier like phone
			// @param $type: type of $data like phone or location
			// @param @need: what we want lik *, fname, lname

			global $conn;
			$data = mysqli_real_escape_string($conn, $data);
			$type = mysqli_real_escape_string($conn, $type);
			$need = mysqli_real_escape_string($conn, $need);

			$query = mysqli_query($conn, "SELECT * FROM citizen WHERE `$type` = \"$data\"") or die(mysqli_error($conn));
			$data = mysqli_fetch_assoc($query);

			return $data;
		}
		function nGender($gender){
			//returns number of citizens who are $gender
			global $conn;
			$query = mysqli_query($conn, "SELECT COUNT(*) as sum FROM citizen WHERE gender = \"$gender\"") or die(mysqli_error($conn));
			$data = mysqli_fetch_assoc($query);
			return $data['sum'];
		}
		function nGenPro($gender, $pro){
			global $conn;
			//Number of $gender in $pro
			if(!is_numeric($pro)){
				//Searchimg the id of profession
				include_once "class.profession.php";
				$prof_id = $Pro->id($pro);
				return $this->nGenPro($gender, $prof_id);
			}

			$query = mysqli_query($conn, "SELECT COUNT(id) as sum FROM citizen WHERE profession = '$pro' AND gender = '$gender'") or die(elog(mysqli_error($conn)));
			$data = mysqli_fetch_assoc($query);
			return $data['sum'];
		}
		function nProfession($pro){
			//Number of people in a $pro
			global $conn;
			if(!is_numeric($pro) && $pro!=''){
				//Searchimg the id of profession
				include_once "class.profession.php";
				$prof_id = $Pro->id($pro);
				return $this->nProfession($prof_id);
			}
			$query = mysqli_query($conn, "SELECT COUNT(id) as sum FROM citizen WHERE profession = '$pro'") or die(elog(mysqli_error($conn)));
			$data = mysqli_fetch_assoc($query);
			return $data['sum'];
		}
		function nMale(){
			//Number of males
			$query = mysqli_query($conn, "SELECT COUNT(*) as sum FROM citizen WHERE gender = \"M\"") or die(mysqli_error($conn));
			$data = mysqli_fetch_assoc($query);
			return $data['sum'];

		}
		function nFemale(){
			//Number of females
			$query = mysqli_query($conn, "SELECT COUNT(*) as sum FROM citizen WHERE gender = \"F\"") or die(mysqli_error($conn));
			$data = mysqli_fetch_assoc($query);
			return $data['sum'];
		}	
		function numCitizen(){
			global $conn;
			$query = mysqli_query($conn, "SELECT COUNT(*) AS count FROM citizen") or die(mysqli_error($conn));
			$data = mysqli_fetch_assoc($query);
			return $data['count'];
		}
	}
	$Citizen = new citizen();
?>

	

