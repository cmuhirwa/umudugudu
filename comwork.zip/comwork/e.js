var ctx = document.getElementById("locGraph");
var testGraph = locgraph = new Chart(ctx, {
			type: 'line',
			data: {
				labels: ['Western Province', 'Kigali City', 'South Province', 'North Province'],
				datasets: [{
					label: '# of attendance in provinces',
            		data: [7, 1, 1, 1],
            		fill: true,
            		backgroundColor: ['rgba(2, 132, 239, .39)','rgba(2, 132, 239, .39)','rgba(2, 132, 239, .39)','rgba(2, 132, 239, .39)',],
            		borderColor: ['rgba(2, 132, 239, .89)'],
				},
                {
                    label: '# of citizens in provinces',
                    data: [10, 2, 1, 1],
                    backgroundColor: ['rgba(0, 0, 000, .09)','rgba(0, 0, 000, .09)','rgba(0, 0, 000, .09)','rgba(0, 0, 000, .09)',],  
                }]
			},
			options: {
				scales: {
					yAxes:[{
						stacked: false,
						ticks: {
							beginAtZero: true
						},
						gridLines: {
			                offsetGridLines: true
			            }
					}],
					xAxes:[{
						gridLines: {
                		offsetGridLines: true
            			},
						stacked: true,
					}]
				}
			}
		})