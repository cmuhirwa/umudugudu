<?php


include("db.php");

$req = array_merge($_POST, $_GET);

$codecell = $req['codecell']??'';
if(!$codecell)
	echo json_encode(array("error" => "no codecell"));


$get_village = mysqli_query($con,"SELECT * FROM  villages WHERE codecell ='".$codecell."'") or die("error:".mysqli_error($con));

	echo "<select name=\"CodeVillage\" id=\"CodeVillage\">";
	if(mysqli_fetch_array($get_village)==0){
		echo "<option value=\"No village Available\">No village Available</option>";
	}else{
	
	echo "<option value=\"\">------Select village------</option>";
		while($row=mysqli_fetch_array($get_village)){
			echo "<option value=\"".$row['CodeVillage']."\">".$row['VillageName']."</option>";
		}
	}
	echo "</select><br>";
	?>
	
